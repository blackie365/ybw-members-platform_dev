"use client"

import { useState } from "react"
import {
  WelcomeEmail,
  PasswordResetEmail,
  PaymentReceiptEmail,
  RenewalReminderEmail,
  NewContentEmail,
  EventInvitationEmail,
  MembershipExpiringEmail,
  AccountUpdateEmail,
  MonthlyDigestEmail,
} from "@/components/emails"

type EmailTemplate =
  | "welcome"
  | "password-reset"
  | "payment-receipt"
  | "renewal-reminder"
  | "new-content"
  | "event-invitation"
  | "membership-expiring"
  | "account-update"
  | "monthly-digest"

const templates: { id: EmailTemplate; name: string; description: string }[] = [
  {
    id: "welcome",
    name: "Welcome Email",
    description: "Sent when a new member joins",
  },
  {
    id: "password-reset",
    name: "Password Reset",
    description: "Password reset request",
  },
  {
    id: "payment-receipt",
    name: "Payment Receipt",
    description: "Confirmation of payment",
  },
  {
    id: "renewal-reminder",
    name: "Renewal Reminder",
    description: "Upcoming auto-renewal notice",
  },
  {
    id: "new-content",
    name: "New Content",
    description: "New resource or article notification",
  },
  {
    id: "event-invitation",
    name: "Event Invitation",
    description: "Invitation to member events",
  },
  {
    id: "membership-expiring",
    name: "Membership Expiring",
    description: "Membership expiration warning",
  },
  {
    id: "account-update",
    name: "Account Update",
    description: "Account security notification",
  },
  {
    id: "monthly-digest",
    name: "Monthly Digest",
    description: "Monthly community roundup",
  },
]

export default function EmailTemplatesPage() {
  const [selectedTemplate, setSelectedTemplate] = useState<EmailTemplate>("welcome")

  const renderTemplate = () => {
    switch (selectedTemplate) {
      case "welcome":
        return <WelcomeEmail firstName="Sarah" membershipTier="Professional" />
      case "password-reset":
        return (
          <PasswordResetEmail
            firstName="Sarah"
            resetLink="https://yorkshirebusinesswoman.com/reset?token=abc123"
            expiryHours={24}
          />
        )
      case "payment-receipt":
        return (
          <PaymentReceiptEmail
            firstName="Sarah"
            invoiceNumber="INV-2024-001234"
            paymentDate="15 January 2024"
            membershipTier="Professional Membership"
            amount="149"
            billingPeriod="15 Jan 2024 - 14 Jan 2025"
            paymentMethod="Visa ending in 4242"
          />
        )
      case "renewal-reminder":
        return (
          <RenewalReminderEmail
            firstName="Sarah"
            membershipTier="Professional"
            renewalDate="15 January 2025"
            amount="149"
            daysRemaining={7}
          />
        )
      case "new-content":
        return (
          <NewContentEmail
            firstName="Sarah"
            contentTitle="10 Strategies for Scaling Your Service-Based Business"
            contentType="Guide"
            contentDescription="Discover proven strategies from successful Yorkshire businesswomen who have scaled their service-based businesses to six figures and beyond."
            contentAuthor="Emma Richardson"
            contentLink="https://yorkshirebusinesswoman.com/resources/scaling-strategies"
          />
        )
      case "event-invitation":
        return (
          <EventInvitationEmail
            firstName="Sarah"
            eventTitle="Spring Networking Brunch"
            eventDate="Saturday, 23rd March 2024"
            eventTime="10:30 AM - 1:00 PM"
            eventLocation="The Ivy, Leeds"
            eventDescription="Join us for an elegant networking brunch with 30 fellow businesswomen. Enjoy a three-course meal while making meaningful connections in a relaxed, supportive atmosphere."
            isOnline={false}
            eventLink="https://yorkshirebusinesswoman.com/events/spring-brunch"
          />
        )
      case "membership-expiring":
        return (
          <MembershipExpiringEmail
            firstName="Sarah"
            membershipTier="Professional"
            expiryDate="31 January 2024"
            renewalAmount="149"
          />
        )
      case "account-update":
        return (
          <AccountUpdateEmail
            firstName="Sarah"
            updateType="password"
            updateDate="15 January 2024"
            updateTime="2:34 PM GMT"
          />
        )
      case "monthly-digest":
        return (
          <MonthlyDigestEmail
            firstName="Sarah"
            monthYear="January 2024"
            stats={{
              newResources: 8,
              upcomingEvents: 4,
              newMembers: 23,
            }}
            featuredContent={[
              {
                title: "Financial Planning for Q1 2024",
                type: "Masterclass Recording",
                link: "#",
              },
              {
                title: "Brand Photography Checklist",
                type: "Template",
                link: "#",
              },
              {
                title: "Managing Difficult Client Conversations",
                type: "Workshop",
                link: "#",
              },
            ]}
            upcomingEvents={[
              {
                title: "Virtual Coffee Morning",
                date: "Tuesday, 23rd January at 9:30 AM",
                link: "#",
              },
              {
                title: "Marketing Masterclass: Social Media Strategy",
                date: "Thursday, 1st February at 7:00 PM",
                link: "#",
              },
            ]}
          />
        )
      default:
        return null
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h1 className="font-serif text-3xl md:text-4xl font-medium tracking-tight">
            Email Templates
          </h1>
          <p className="mt-2 text-primary-foreground/70">
            Yorkshire Businesswoman membership site email suite
          </p>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <aside className="lg:col-span-1">
            <nav className="space-y-1">
              {templates.map((template) => (
                <button
                  key={template.id}
                  onClick={() => setSelectedTemplate(template.id)}
                  className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
                    selectedTemplate === template.id
                      ? "bg-accent text-accent-foreground"
                      : "hover:bg-muted text-foreground"
                  }`}
                >
                  <span className="font-medium block">{template.name}</span>
                  <span
                    className={`text-sm ${
                      selectedTemplate === template.id
                        ? "text-accent-foreground/80"
                        : "text-muted-foreground"
                    }`}
                  >
                    {template.description}
                  </span>
                </button>
              ))}
            </nav>
          </aside>

          {/* Preview */}
          <main className="lg:col-span-3">
            <div className="bg-card border border-border rounded-lg overflow-hidden">
              <div className="bg-muted px-4 py-3 border-b border-border flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-400" />
                <div className="w-3 h-3 rounded-full bg-yellow-400" />
                <div className="w-3 h-3 rounded-full bg-green-400" />
                <span className="ml-4 text-sm text-muted-foreground">
                  Email Preview
                </span>
              </div>
              <div className="p-0">{renderTemplate()}</div>
            </div>
          </main>
        </div>
      </div>
    </div>
  )
}
